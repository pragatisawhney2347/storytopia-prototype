package com.storytopia.app

import android.content.Context
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.storytopia.app.ui.cleanser.CleanserFragment
import com.storytopia.app.ui.notes.NotesFragment
import com.storytopia.app.ui.producer.ProducerFragment

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var navView: NavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        // 1. Apply Theme BEFORE super.onCreate (Fixes theme switching)
        applySavedTheme()
        super.onCreate(savedInstanceState)

        // 2. Set the Fixed Layout (No more "simple" fallback)
        setContentView(R.layout.activity_main_with_drawer)

        // 3. Initialize Views
        drawerLayout = findViewById(R.id.drawer_layout)
        bottomNav = findViewById(R.id.bottom_navigation)
        navView = findViewById(R.id.nav_view)
        val toolbar = findViewById<Toolbar>(R.id.toolbar)

        // 4. Setup Toolbar & Drawer
        setSupportActionBar(toolbar)
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar,
            R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        // 5. Setup Listeners
        navView.setNavigationItemSelectedListener(this)
        setupBottomNav()

        // 6. Load default fragment
        if (savedInstanceState == null) {
            loadFragment(CleanserFragment())
            bottomNav.selectedItemId = R.id.nav_cleanser
        }
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_cleanser -> loadFragment(CleanserFragment())
                R.id.nav_producer -> loadFragment(ProducerFragment())
                R.id.nav_notes -> loadFragment(NotesFragment())
                else -> false
            }
            true
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // Handle Sidebar Theme Switches
        val themeName = when (item.itemId) {
            R.id.nav_theme_indigo -> "indigo"
            R.id.nav_theme_purple -> "purple"
            R.id.nav_theme_blue -> "blue"
            R.id.nav_theme_pink -> "pink"
            R.id.nav_theme_dark -> "dark"
            R.id.nav_theme_light -> "light"
            else -> null
        }

        if (themeName != null) {
            saveTheme(themeName)
            recreate() // Restart app to apply new theme
        }

        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun applySavedTheme() {
        val prefs = getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
        val themeStyle = when (prefs.getString("current_theme", "indigo")) {
            "purple" -> R.style.Theme_StoryTopia_Purple
            "blue" -> R.style.Theme_StoryTopia_Blue
            "pink" -> R.style.Theme_StoryTopia_Pink
            "dark" -> R.style.Theme_StoryTopia_Dark
            "light" -> R.style.Theme_StoryTopia_Light
            else -> R.style.Theme_StoryTopia_Indigo
        }
        setTheme(themeStyle)
    }

    private fun saveTheme(themeName: String) {
        getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("current_theme", themeName)
            .apply()
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}