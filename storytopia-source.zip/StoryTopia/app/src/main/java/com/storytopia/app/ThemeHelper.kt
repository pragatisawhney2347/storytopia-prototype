package com.storytopia.app

import android.content.Context

object ThemeHelper {

    fun getBackgroundGradient(context: Context): Int {
        val prefs = context.getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
        return when (prefs.getString("current_theme", "indigo")) {
            "purple" -> R.drawable.gradient_purple
            "blue" -> R.drawable.gradient_blue
            "pink" -> R.drawable.gradient_pink
            "dark" -> R.drawable.gradient_dark
            "light" -> R.drawable.gradient_light
            else -> R.drawable.gradient_indigo
        }
    }

    fun getButtonGradient(context: Context): Int {
        val prefs = context.getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
        return when (prefs.getString("current_theme", "indigo")) {
            "purple" -> R.drawable.button_purple
            "blue" -> R.drawable.button_blue
            "pink" -> R.drawable.button_pink
            "dark" -> R.drawable.button_dark
            "light" -> R.drawable.button_light
            else -> R.drawable.button_indigo
        }
    }

    fun getToolbarGradient(context: Context): Int {
        return getBackgroundGradient(context)
    }
}