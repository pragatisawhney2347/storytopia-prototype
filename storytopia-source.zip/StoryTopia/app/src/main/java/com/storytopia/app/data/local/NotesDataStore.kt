package com.storytopia.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.storytopia.app.data.model.Note
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "notes_storage")

class NotesDataStore(private val context: Context) {

    private val gson = Gson()
    private val NOTES_KEY = stringPreferencesKey("notes_list")

    suspend fun saveNotes(notes: List<Note>) {
        val json = gson.toJson(notes)
        context.dataStore.edit { preferences ->
            preferences[NOTES_KEY] = json
        }
    }

    fun getNotes(): Flow<List<Note>> {
        return context.dataStore.data.map { preferences ->
            val json = preferences[NOTES_KEY] ?: "[]"
            val type = object : TypeToken<List<Note>>() {}.type
            gson.fromJson(json, type)
        }
    }

    suspend fun addNote(note: Note, existingNotes: List<Note>): Long {
        val newId = (existingNotes.maxOfOrNull { it.id } ?: 0) + 1
        val newNote = note.copy(id = newId, timestamp = System.currentTimeMillis())
        val updatedNotes = existingNotes + newNote
        saveNotes(updatedNotes)
        return newId
    }

    suspend fun updateNote(note: Note, existingNotes: List<Note>) {
        val updatedNotes = existingNotes.map {
            if (it.id == note.id) note else it
        }
        saveNotes(updatedNotes)
    }

    suspend fun deleteNote(noteId: Long, existingNotes: List<Note>) {
        val updatedNotes = existingNotes.filter { it.id != noteId }
        saveNotes(updatedNotes)
    }
}