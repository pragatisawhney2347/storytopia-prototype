package com.storytopia.app.data.local

// Database now handled by DataStore
object NotesDatabase {
    // Placeholder - using DataStore for persistence
}