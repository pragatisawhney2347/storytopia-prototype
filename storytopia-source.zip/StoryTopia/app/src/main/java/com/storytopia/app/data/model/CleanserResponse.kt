package com.storytopia.app.data.model

data class CleanserResponse(
    val keyIdeas: List<String>,
    val significantThoughts: List<String>,
    val flow: String,
    val noise: String
)