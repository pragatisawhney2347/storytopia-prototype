package com.storytopia.app.data.model

data class Note(
    val id: Long = 0,
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isBold: Boolean = false,
    val isItalic: Boolean = false,
    val hasBullets: Boolean = false
)