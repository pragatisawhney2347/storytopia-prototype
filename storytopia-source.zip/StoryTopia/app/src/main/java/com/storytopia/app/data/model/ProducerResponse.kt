package com.storytopia.app.data.model

data class ProducerResponse(
    val continuations: List<StoryContinuation>
)

data class StoryContinuation(
    val type: String,
    val title: String,
    val description: String
)