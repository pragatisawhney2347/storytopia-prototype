package com.storytopia.app.data.repository

import com.google.gson.Gson
import com.storytopia.app.data.model.CleanserResponse
import com.storytopia.app.data.model.ProducerResponse
import com.storytopia.app.network.OpenRouterClient
import com.storytopia.app.network.OpenRouterMessage
import com.storytopia.app.network.OpenRouterRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class AIRepository {

    private val apiService = OpenRouterClient.apiService
    private val gson = Gson()

    /**
     * Cleanses a messy story idea.
     * Uses Dispatchers.IO for background thread safety and handles specific network exceptions.
     */
    suspend fun cleanseIdea(messyPrompt: String, apiKey: String): Result<CleanserResponse> {
        return withContext(Dispatchers.IO) {
            try {
                val prompt = """Analyze this messy story idea and extract key elements.
Idea: $messyPrompt

Respond ONLY with valid JSON:
{"keyIdeas":["idea1"],"significantThoughts":["thought1"],"flow":"structure","noise":"remove"}"""

                val request = OpenRouterRequest(
                    messages = listOf(OpenRouterMessage(role = "user", content = prompt))
                )

                val response = apiService.chat("Bearer $apiKey", request)
                val generatedText = response.choices.firstOrNull()?.message?.content
                    ?: throw Exception("The AI returned an empty response.")

                val cleanJson = extractJson(generatedText)
                val result = gson.fromJson(cleanJson, CleanserResponse::class.java)
                Result.success(result)

            } catch (e: UnknownHostException) {
                // Background thread safety: We catch the specific "No Internet" error
                Result.failure(Exception("No internet connection. Please check your network."))
            } catch (e: SocketTimeoutException) {
                // Cancellation/Timeout handling: Triggered if the 60s limit is reached
                Result.failure(Exception("The AI is taking too long to respond. Try again later."))
            } catch (e: Exception) {
                // Exception propagation: Pass a clean message back to the ViewModel
                Result.failure(Exception("AI Error: ${e.localizedMessage}"))
            }
        }
    }

    /**
     * Produces story continuations or endings.
     */
    suspend fun produceIdeas(context: String, isEnding: Boolean, apiKey: String): Result<ProducerResponse> {
        return withContext(Dispatchers.IO) {
            try {
                val goal = if (isEnding) "story endings" else "continuation ideas"
                val prompt = """Generate $goal for: $context
Respond ONLY with valid JSON:
{"continuations":[{"type":"Plot Twist","title":"Title","description":"Description"}]}"""

                val request = OpenRouterRequest(
                    messages = listOf(OpenRouterMessage(role = "user", content = prompt))
                )

                val response = apiService.chat("Bearer $apiKey", request)
                val generatedText = response.choices.firstOrNull()?.message?.content
                    ?: throw Exception("No response from AI.")

                val cleanJson = extractJson(generatedText)
                val result = gson.fromJson(cleanJson, ProducerResponse::class.java)
                Result.success(result)

            } catch (e: UnknownHostException) {
                Result.failure(Exception("Internet connection lost."))
            } catch (e: SocketTimeoutException) {
                Result.failure(Exception("Request timed out. The server might be busy."))
            } catch (e: Exception) {
                Result.failure(Exception("Production Error: ${e.localizedMessage}"))
            }
        }
    }

    private fun extractJson(text: String): String {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start != -1 && end != -1 && end > start) {
            return text.substring(start, end + 1)
        }
        throw Exception("Invalid response format from AI")
    }
}