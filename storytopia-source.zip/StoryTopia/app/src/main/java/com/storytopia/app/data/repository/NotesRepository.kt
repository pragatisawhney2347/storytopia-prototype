package com.storytopia.app.data.repository

import android.content.Context
import com.storytopia.app.data.local.NotesDataStore
import com.storytopia.app.data.model.Note
import kotlinx.coroutines.flow.first

class NotesRepository(context: Context) {
    private val dataStore = NotesDataStore(context)

    suspend fun getAllNotes(): List<Note> {
        return dataStore.getNotes().first()
    }

    suspend fun getNoteById(id: Long): Note? {
        return getAllNotes().find { it.id == id }
    }

    suspend fun addNote(note: Note): Long {
        val existing = getAllNotes()
        return dataStore.addNote(note, existing)
    }

    suspend fun updateNote(note: Note) {
        val existing = getAllNotes()
        dataStore.updateNote(note, existing)
    }

    suspend fun deleteNote(noteId: Long) {
        val existing = getAllNotes()
        dataStore.deleteNote(noteId, existing)
    }
}