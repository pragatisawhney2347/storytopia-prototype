package com.storytopia.app.ui.cleanser

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.storytopia.app.BuildConfig
import com.storytopia.app.R
import com.storytopia.app.ThemeHelper
import com.storytopia.app.data.model.CleanserResponse

class CleanserFragment : Fragment() {

    private val viewModel: CleanserViewModel by viewModels()

    private lateinit var inputEditText: EditText
    private lateinit var cleanseButton: Button
    private lateinit var resultTextView: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var resultCard: View

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_cleanser, container, false)

        // Apply theme
        view.findViewById<View>(R.id.cleanser_root).setBackgroundResource(
            ThemeHelper.getBackgroundGradient(requireContext())
        )

        inputEditText = view.findViewById(R.id.input_edit_text)
        cleanseButton = view.findViewById(R.id.cleanse_button)
        resultTextView = view.findViewById(R.id.result_text_view)
        progressBar = view.findViewById(R.id.progress_bar)
        resultCard = view.findViewById(R.id.result_card)

        // Apply button theme
        cleanseButton.setBackgroundResource(
            ThemeHelper.getButtonGradient(requireContext())
        )

        cleanseButton.setOnClickListener {
            val messyIdea = inputEditText.text.toString()
            val apiKey = BuildConfig.OPENROUTER_API_KEY
            viewModel.cleanseIdea(messyIdea, apiKey)
        }

        observeViewModel()

        return view
    }

    private fun observeViewModel() {
        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            cleanseButton.isEnabled = !isLoading
            if (isLoading) resultCard.visibility = View.GONE
        }

        viewModel.cleanserResult.observe(viewLifecycleOwner) { result ->
            result?.let {
                displayResult(it)
                resultCard.visibility = View.VISIBLE
            }
        }

        viewModel.error.observe(viewLifecycleOwner) { error ->
            error?.let {
                Toast.makeText(requireContext(), it, Toast.LENGTH_LONG).show()
                resultCard.visibility = View.GONE
            }
        }
    }

    private fun displayResult(result: CleanserResponse) {
        val formattedResult = buildString {
            append("📌 KEY IDEAS\n")
            result.keyIdeas.forEach { append("• $it\n") }
            append("\n💭 SIGNIFICANT THOUGHTS\n")
            result.significantThoughts.forEach { append("• $it\n") }
            append("\n🌊 NARRATIVE FLOW\n${result.flow}\n")
            append("\n🔇 NOISE TO FILTER\n${result.noise}")
        }
        resultTextView.text = formattedResult
    }
}