package com.storytopia.app.ui.cleanser

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.storytopia.app.data.model.CleanserResponse
import com.storytopia.app.data.repository.AIRepository
import kotlinx.coroutines.launch

class CleanserViewModel : ViewModel() {

    private val repository = AIRepository()

    private val _cleanserResult = MutableLiveData<CleanserResponse?>()
    val cleanserResult: LiveData<CleanserResponse?> = _cleanserResult

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    fun cleanseIdea(messyPrompt: String, apiKey: String) {
        if (messyPrompt.trim().isEmpty()) {
            _error.value = "Your idea can't be empty! Write something first."
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null

            val result = repository.cleanseIdea(messyPrompt, apiKey)

            result.fold(
                onSuccess = { response ->
                    _cleanserResult.value = response
                    _isLoading.value = false
                },
                onFailure = { exception ->
                    _error.value = "Error: ${exception.message}"
                    _isLoading.value = false
                }
            )
        }
    }
}