package com.storytopia.app.ui.notes

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ImageSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.storytopia.app.R
import com.storytopia.app.ThemeHelper
import com.storytopia.app.data.model.Note
import java.io.InputStream

class NoteEditorActivity : AppCompatActivity() {

    private lateinit var viewModel: NotesViewModel
    private lateinit var titleInput: EditText
    private lateinit var contentInput: EditText
    private var existingNoteId: Long = -1L

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) openImagePicker() else Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
    }

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { uri -> insertImage(uri) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note_editor)

        viewModel = ViewModelProvider(this)[NotesViewModel::class.java]

        titleInput = findViewById(R.id.note_title_input)
        contentInput = findViewById(R.id.note_content_input)

        findViewById<android.view.View>(R.id.editor_root).setBackgroundResource(
            ThemeHelper.getBackgroundGradient(this)
        )

        existingNoteId = intent.getLongExtra("NOTE_ID", -1L)
        if (existingNoteId != -1L) {
            titleInput.setText(intent.getStringExtra("NOTE_TITLE"))

            // IMPORTANT: Handle loading the content with spans
            val rawContent = intent.getStringExtra("NOTE_CONTENT") ?: ""
            loadContentWithSpans(rawContent)
        }

        setupButtons()
    }

    private fun setupButtons() {
        findViewById<ImageButton>(R.id.btn_back).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.btn_save).setOnClickListener { saveNote() }
        findViewById<ImageButton>(R.id.btn_image).setOnClickListener { checkStoragePermission() }

        findViewById<ImageButton>(R.id.btn_bold).setOnClickListener { applyStyle(Typeface.BOLD) }
        findViewById<ImageButton>(R.id.btn_italic).setOnClickListener { applyStyle(Typeface.ITALIC) }
        findViewById<ImageButton>(R.id.btn_underline).setOnClickListener { applyUnderline() }

        findViewById<ImageButton>(R.id.btn_bullet).setOnClickListener {
            val start = contentInput.selectionStart
            contentInput.text.insert(start, "\n• ")
        }
    }

    /**
     * Logic to scan the saved string for [IMG:uri] tags and convert them back to Spans
     */
    private fun loadContentWithSpans(rawText: String) {
        val builder = SpannableStringBuilder(rawText)
        val pattern = Regex("\\[IMG:(.*?)\\]")
        val matches = pattern.findAll(rawText).toList().reversed() // Process backwards to keep indices valid

        for (match in matches) {
            val uriString = match.groupValues[1]
            val uri = Uri.parse(uriString)
            val start = match.range.first
            val end = match.range.last + 1

            try {
                val bitmap = getBitmapFromUri(uri)
                if (bitmap != null) {
                    val imageSpan = ImageSpan(this, bitmap)
                    builder.setSpan(imageSpan, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            } catch (e: Exception) {
                // If image is missing/deleted from phone, we just leave the text tag
            }
        }
        contentInput.setText(builder)
    }

    private fun applyStyle(style: Int) {
        val start = contentInput.selectionStart
        val end = contentInput.selectionEnd
        if (start != end) {
            contentInput.text.setSpan(StyleSpan(style), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    private fun applyUnderline() {
        val start = contentInput.selectionStart
        val end = contentInput.selectionEnd
        if (start != end) {
            contentInput.text.setSpan(UnderlineSpan(), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    private fun saveNote() {
        val title = titleInput.text.toString().trim()
        val content = contentInput.text.toString().trim() // This saves the [IMG:uri] tags

        if (title.isEmpty() || content.isEmpty()) {
            Toast.makeText(this, "Title and content cannot be empty", Toast.LENGTH_SHORT).show()
            return
        }

        if (existingNoteId == -1L) {
            viewModel.addNote(title, content)
        } else {
            viewModel.updateNote(Note(id = existingNoteId, title = title, content = content))
        }
        finish()
    }

    private fun checkStoragePermission() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            openImagePicker()
        } else {
            requestPermissionLauncher.launch(permission)
        }
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            // Ensure we keep access to this file after app closes
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        imagePickerLauncher.launch(intent)
    }

    private fun insertImage(uri: Uri) {
        // Persist permission so we can load this URI again later
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)

        val bitmap = getBitmapFromUri(uri)
        if (bitmap != null) {
            val start = contentInput.selectionStart
            // We save the URI inside the tag so we know WHICH image to load later
            val tag = "[IMG:$uri]"

            contentInput.text.insert(start, "\n$tag\n")
            val imageSpan = ImageSpan(this, bitmap)
            contentInput.text.setSpan(
                imageSpan,
                start + 1,
                start + 1 + tag.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }

    private fun getBitmapFromUri(uri: Uri): Bitmap? {
        return try {
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            bitmap?.let {
                val screenWidth = resources.displayMetrics.widthPixels - 100
                val aspectRatio = it.height.toFloat() / it.width.toFloat()
                val newHeight = (screenWidth * aspectRatio).toInt()
                Bitmap.createScaledBitmap(it, screenWidth, newHeight, true)
            }
        } catch (e: Exception) {
            null
        }
    }
}