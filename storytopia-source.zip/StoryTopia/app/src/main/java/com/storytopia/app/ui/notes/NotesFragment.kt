package com.storytopia.app.ui.notes

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.storytopia.app.R
import com.storytopia.app.ThemeHelper
import com.storytopia.app.data.model.Note

class NotesFragment : Fragment() {

    private val viewModel: NotesViewModel by viewModels()

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyStateText: TextView
    private lateinit var fabAddNote: FloatingActionButton
    private lateinit var notesAdapter: NotesAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_notes, container, false)

        // Apply theme
        view.findViewById<View>(R.id.notes_root).setBackgroundResource(
            ThemeHelper.getBackgroundGradient(requireContext())
        )

        recyclerView = view.findViewById(R.id.notes_recycler_view)
        emptyStateText = view.findViewById(R.id.empty_state_text)
        fabAddNote = view.findViewById(R.id.fab_add_note)

        setupRecyclerView()

        fabAddNote.setOnClickListener {
            openNoteEditor(null)
        }

        observeViewModel()

        return view
    }

    override fun onResume() {
        super.onResume()
        viewModel.loadNotes()
    }

    private fun setupRecyclerView() {
        notesAdapter = NotesAdapter(
            notes = emptyList(),
            onNoteClick = { note -> openNoteEditor(note) },
            onNoteLongClick = { note -> showDeleteDialog(note) }
        )
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = notesAdapter
    }

    private fun openNoteEditor(note: Note?) {
        val intent = Intent(requireContext(), NoteEditorActivity::class.java)
        note?.let {
            intent.putExtra("NOTE_ID", it.id)
            intent.putExtra("NOTE_TITLE", it.title)
            intent.putExtra("NOTE_CONTENT", it.content)
        }
        startActivity(intent)
    }

    private fun showDeleteDialog(note: Note) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Note")
            .setMessage("Are you sure you want to delete '${note.title}'?")
            .setPositiveButton("Delete") { _, _ ->
                viewModel.deleteNote(note.id)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun observeViewModel() {
        viewModel.notes.observe(viewLifecycleOwner) { notes ->
            if (notes.isEmpty()) {
                emptyStateText.visibility = View.VISIBLE
                recyclerView.visibility = View.GONE
            } else {
                emptyStateText.visibility = View.GONE
                recyclerView.visibility = View.VISIBLE
                notesAdapter.updateNotes(notes)
            }
        }
    }
}