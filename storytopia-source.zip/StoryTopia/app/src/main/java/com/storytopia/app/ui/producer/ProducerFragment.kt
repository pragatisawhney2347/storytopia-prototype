package com.storytopia.app.ui.producer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.storytopia.app.BuildConfig
import com.storytopia.app.R
import com.storytopia.app.ThemeHelper
import com.storytopia.app.data.model.ProducerResponse

class ProducerFragment : Fragment() {

    private val viewModel: ProducerViewModel by viewModels()

    private lateinit var storyContextInput: EditText
    private lateinit var storyGoalRadio: RadioGroup
    private lateinit var produceButton: Button
    private lateinit var resultTextView: TextView
    private lateinit var progressBar: ProgressBar

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_producer, container, false)

        // Apply theme
        view.findViewById<View>(R.id.producer_root).setBackgroundResource(
            ThemeHelper.getBackgroundGradient(requireContext())
        )

        storyContextInput = view.findViewById(R.id.story_context_input)
        storyGoalRadio = view.findViewById(R.id.story_goal_radio)
        produceButton = view.findViewById(R.id.produce_button)
        resultTextView = view.findViewById(R.id.result_text_view)
        progressBar = view.findViewById(R.id.progress_bar)

        // Apply button theme
        produceButton.setBackgroundResource(
            ThemeHelper.getButtonGradient(requireContext())
        )

        produceButton.setOnClickListener {
            val context = storyContextInput.text.toString()
            val isEnding = storyGoalRadio.checkedRadioButtonId == R.id.radio_end
            val apiKey = BuildConfig.OPENROUTER_API_KEY
            viewModel.produceIdeas(context, isEnding, apiKey)
        }

        observeViewModel()

        return view
    }

    private fun observeViewModel() {
        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            produceButton.isEnabled = !isLoading
        }

        viewModel.producerResult.observe(viewLifecycleOwner) { result ->
            result?.let {
                displayResult(it)
            }
        }

        viewModel.error.observe(viewLifecycleOwner) { error ->
            error?.let {
                Toast.makeText(requireContext(), it, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun displayResult(result: ProducerResponse) {
        val formattedResult = buildString {
            append("📖 STORY CONTINUATIONS\n\n")
            result.continuations.forEachIndexed { index, continuation ->
                append("${index + 1}. ${continuation.title}\n")
                append("   Type: ${continuation.type}\n")
                append("   ${continuation.description}\n\n")
            }
        }
        resultTextView.text = formattedResult
    }
}