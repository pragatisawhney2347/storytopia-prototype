package com.storytopia.app.ui.producer

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.storytopia.app.data.model.ProducerResponse
import com.storytopia.app.data.repository.AIRepository
import kotlinx.coroutines.launch

class ProducerViewModel : ViewModel() {

    private val repository = AIRepository()

    private val _producerResult = MutableLiveData<ProducerResponse?>()
    val producerResult: LiveData<ProducerResponse?> = _producerResult

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    fun produceIdeas(context: String, isEnding: Boolean, apiKey: String) {
        if (context.isBlank()) {
            _error.value = "Please enter story context first"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null

            val result = repository.produceIdeas(context, isEnding, apiKey)

            result.fold(
                onSuccess = { response ->
                    _producerResult.value = response
                    _isLoading.value = false
                },
                onFailure = { exception ->
                    _error.value = "Error: ${exception.message}"
                    _isLoading.value = false
                }
            )
        }
    }
}